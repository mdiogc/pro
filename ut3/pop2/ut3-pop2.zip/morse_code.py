# ************
# CÓDIGO MORSE
# ************
from pathlib import Path


def run(morse_signals: Path, sentence: str) -> str:
    # TU CÓDIGO AQUÍ
    morse_sentence = 'output'

    return morse_sentence


if __name__ == '__main__':
    run('data/morse_code/signals.morse', 'hello, world!')