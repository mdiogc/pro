# *******************************
# VENTAS EN TIENDA DE INFORMÁTICA
# *******************************


def run(sales: list) -> tuple:
    # TU CÓDIGO AQUÍ
    pcs = displays = 'output'

    return pcs, displays


if __name__ == '__main__':
    run([[4, 5], [1, 3], [3, 2]])