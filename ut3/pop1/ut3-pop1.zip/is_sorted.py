# ***************
# ¿ESTÁ ORDENADO?
# ***************


def run(items: list) -> bool:
    # TU CÓDIGO AQUÍ
    items_sorted = 'output'

    return items_sorted


if __name__ == '__main__':
    run(['a', 'f', 't'])