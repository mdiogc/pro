# ***************
# COLORES EN HEXA
# ***************


def run(hex_color: str) -> str:
    red =
    green =
    blue =

    rgb_color = 


    return rgb_color


if __name__ == '__main__':
    run('A131F7')
