# *************************
# CONTANDO LETRAS Y DÍGITOS
# *************************


def run(text: str) -> tuple:
    ALPHABET = 'abcdefghijklmnñopqrstuvwxyz'
    DIGITS = '0123456789'

    for num_digits in range(0, 10):
        print(DIGITS)
    if text == ALPHABET:
        num_letters = 

    return num_letters, num_digits


if __name__ == '__main__':
    run('pycheck 1.2.35')
