# **********************
# CONVIRTIENDO ADN A ARN
# **********************


def run(adn: str) -> str:
    return arn


if __name__ == '__main__':
    run('AGTCCCAGGT')
